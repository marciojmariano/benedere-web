import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { MultiSelectModule } from 'primeng/multiselect';

import { MarkupService } from '../../core/services/markup.service';
import { IndiceMarkupService } from '../../core/services/indice-markup.service';
import { IndiceMarkup } from '../../core/models';

@Component({
  selector: 'app-markup-form',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, ButtonModule, InputTextModule, ToastModule, MultiSelectModule],
  providers: [MessageService],
  templateUrl: './markup-form.component.html',
})
export class MarkupFormComponent implements OnInit {
  private fb = inject(FormBuilder);
  private service = inject(MarkupService);
  private indiceService = inject(IndiceMarkupService);
  private router = inject(Router);
  private route = inject(ActivatedRoute);
  private messageService = inject(MessageService);

  form!: FormGroup;
  indices: IndiceMarkup[] = [];
  salvando = false;
  markupId: string | null = null;

  ngOnInit(): void {
    this.markupId = this.route.snapshot.paramMap.get('id');
    this.form = this.fb.group({
      nome: ['', [Validators.required, Validators.minLength(2)]],
      descricao: [''],
      indices_ids: [[], [Validators.required, Validators.minLength(1)]],
    });
    this.indiceService.listar().subscribe({ next: (data) => this.indices = data });
    if (this.markupId) {
      this.service.buscarPorId(this.markupId).subscribe({
        next: (data) => {
          this.form.patchValue({
            nome: data.nome,
            descricao: data.descricao,
            indices_ids: data.indices.map((i: any) => i.id),
          });
        },
        error: () => this.voltar(),
      });
    }
  }

  salvar(): void {
    if (this.form.invalid) { this.form.markAllAsTouched(); return; }
    this.salvando = true;
    const req$ = this.markupId
      ? this.service.atualizar(this.markupId, this.form.value)
      : this.service.criar(this.form.value);
    req$.subscribe({
      next: () => { this.messageService.add({ severity: 'success', summary: 'Sucesso', detail: 'Markup salvo!' }); setTimeout(() => this.voltar(), 1000); },
      error: (err) => { this.messageService.add({ severity: 'error', summary: 'Erro', detail: err.error?.detail || 'Erro ao salvar' }); this.salvando = false; },
    });
  }

  voltar(): void { this.router.navigate(['/markups']); }
  isInvalid(campo: string): boolean { const c = this.form.get(campo); return !!(c?.invalid && c?.touched); }
}